import { IData } from "../../data/IData";


export interface IFilterNewsState {
   
    proposedData : IData[];
    currentData : string;
  }
  