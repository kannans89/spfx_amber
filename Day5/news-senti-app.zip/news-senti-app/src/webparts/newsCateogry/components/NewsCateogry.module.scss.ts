/* tslint:disable */
require("./NewsCateogry.module.css");
const styles = {
  newsCateogry: 'newsCateogry_2e35a074',
  teams: 'teams_2e35a074',
  welcome: 'welcome_2e35a074',
  welcomeImage: 'welcomeImage_2e35a074',
  links: 'links_2e35a074'
};

export default styles;
/* tslint:enable */