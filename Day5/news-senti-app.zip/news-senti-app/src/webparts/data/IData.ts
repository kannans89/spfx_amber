export interface IData
{

    keywords:string;
    language : string;
}