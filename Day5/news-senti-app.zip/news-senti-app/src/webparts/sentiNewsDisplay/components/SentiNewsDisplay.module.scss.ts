/* tslint:disable */
require("./SentiNewsDisplay.module.css");
const styles = {
  newsSentiment: 'newsSentiment_5ea301a0',
  container: 'container_5ea301a0',
  row: 'row_5ea301a0',
  column: 'column_5ea301a0',
  'ms-Grid': 'ms-Grid_5ea301a0',
  title: 'title_5ea301a0',
  subTitle: 'subTitle_5ea301a0',
  description: 'description_5ea301a0',
  button: 'button_5ea301a0',
  label: 'label_5ea301a0'
};

export default styles;
/* tslint:enable */