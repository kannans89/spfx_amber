import * as React from 'react';
import type { ISentiNewsDisplayProps } from './ISentiNewsDisplayProps';
import { INewsSentimentState } from './INewsSentimentState';
export default class SentiNewsDisplay extends React.Component<ISentiNewsDisplayProps, INewsSentimentState> {
    private service;
    constructor(props: ISentiNewsDisplayProps);
    componentDidMount(): Promise<void>;
    componentDidUpdate?(prevProps: ISentiNewsDisplayProps, prevState: INewsSentimentState, snapshot: any): Promise<void>;
    private LoadNews;
    render(): React.ReactElement<ISentiNewsDisplayProps>;
}
//# sourceMappingURL=SentiNewsDisplay.d.ts.map