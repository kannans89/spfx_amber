import { IData } from "../../data/IData";
import INews from "./INews";
export interface INewsSentimentState {
    currentkeywords?: IData;
    news?: INews[];
}
//# sourceMappingURL=INewsSentimentState.d.ts.map