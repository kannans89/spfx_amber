import { DynamicProperty } from "@microsoft/sp-component-base";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IData } from "../../data/IData";
export interface ISentiNewsDisplayProps {
    description: string;
    keywords: DynamicProperty<IData>;
    context: WebPartContext;
    bingKey?: string;
    textSentimentApiKey?: string;
    chosenSentiment?: string;
}
//# sourceMappingURL=ISentiNewsDisplayProps.d.ts.map