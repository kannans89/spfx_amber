import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { ISentiNewsDisplayProps } from './components/ISentiNewsDisplayProps';
import { IWebPartPropertiesMetadata } from '@microsoft/sp-webpart-base';
export interface ISentiNewsDisplayWebPartProps {
    description: string;
}
export default class SentiNewsDisplayWebPart extends BaseClientSideWebPart<ISentiNewsDisplayProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected get propertiesMetadata(): IWebPartPropertiesMetadata;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SentiNewsDisplayWebPart.d.ts.map