import { HttpClient } from "@microsoft/sp-http";
import INews from "../components/INews";
import { IData } from "../../data/IData";
export declare class BingService {
    private _ApihttpClient;
    private _cognitiveServicesTextUrl;
    private _bingSearchUrl?;
    private _textSentimentApiKey?;
    private _bingApiKey?;
    constructor(ApihttpClient: HttpClient, textSentimentApiKey?: string, bingApiKey?: string);
    getNewsFromBingAndDetermineSentiments(data: IData): Promise<INews[]>;
    private _getNewsFromBing;
    private _prepareHeadersForBingApi;
    private _getSentiments;
    private _prepareHeadersForSentimentApi;
}
//# sourceMappingURL=BingService.d.ts.map