import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { INewsCateogryProps } from './components/INewsCateogryProps';
import { IData } from '../data/IData';
import { IDynamicDataPropertyDefinition, IDynamicDataCallables } from '@microsoft/sp-dynamic-data';
export default class NewsCateogryWebPart extends BaseClientSideWebPart<INewsCateogryProps> implements IDynamicDataCallables {
    private _currentData;
    private onDataChanged;
    protected onInit(): Promise<void>;
    getPropertyDefinitions(): ReadonlyArray<IDynamicDataPropertyDefinition>;
    /**
     * Return the current value of the specified dynamic data set
     * @param propertyId ID of the dynamic data set to retrieve the value for
     */
    getPropertyValue(propertyId: string): IData;
    /**
     * Returns the friendly annoted values for the property. This info will be used by default SPFx dynamic data property pane fields.
     * @param propertyId the property id
     */
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=NewsCateogryWebPart.d.ts.map