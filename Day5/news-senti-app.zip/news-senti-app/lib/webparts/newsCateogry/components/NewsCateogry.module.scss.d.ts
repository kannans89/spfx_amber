declare const styles: {
    newsCateogry: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=NewsCateogry.module.scss.d.ts.map