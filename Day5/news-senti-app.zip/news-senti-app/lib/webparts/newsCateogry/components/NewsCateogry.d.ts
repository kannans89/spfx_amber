import * as React from 'react';
import type { INewsCateogryProps } from './INewsCateogryProps';
import { IFilterNewsState } from './IFilterNewsState';
export default class NewsCateogry extends React.Component<INewsCateogryProps, IFilterNewsState> {
    constructor(props: INewsCateogryProps);
    componentDidMount(): void;
    render(): React.ReactElement<INewsCateogryProps>;
}
//# sourceMappingURL=NewsCateogry.d.ts.map