import { IData } from "../../data/IData";
export interface IFilterNewsState {
    proposedData: IData[];
    currentData: string;
}
//# sourceMappingURL=IFilterNewsState.d.ts.map