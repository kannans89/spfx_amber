export interface IData {
    keywords: string;
    language: string;
}
//# sourceMappingURL=IData.d.ts.map